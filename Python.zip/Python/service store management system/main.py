# Title              : Service Management system
# Author             : Agateeswaran K
# Created on         : 14/08/2023
# Last Modified Date : 22/08/2023
# Reviewed by        :
# Reviewed on        :

from Controller.controller import Home

if __name__ == "__main__":
    controller = Home()
    controller.greetings()
